-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 23, 2009 at 05:42 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hrm`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `EmployeeID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `EmployeeName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Salary` float NOT NULL,
  `EmployeeStyleID` int(11) NOT NULL,
  PRIMARY KEY (`EmployeeID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EmployeeID`, `EmployeeName`, `Email`, `Salary`, `EmployeeStyleID`) VALUES
('NV002', 'Nguyễn Văn Hùng', 'vnhung@gmail.com', 2e+006, 2),
('NV001', 'Nguyễn Văn Thành', 'nvthanh@gmail.com', 2e+006, 1);

-- --------------------------------------------------------

--
-- Table structure for table `employeestyle`
--

DROP TABLE IF EXISTS `employeestyle`;
CREATE TABLE IF NOT EXISTS `employeestyle` (
  `EmployeeStyleID` int(11) NOT NULL,
  `EmployeeStyleName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`EmployeeStyleID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employeestyle`
--

INSERT INTO `employeestyle` (`EmployeeStyleID`, `EmployeeStyleName`) VALUES
(1, 'Nhân Viên Văn Phòng'),
(2, 'Nhân Viên Kinh Doanh'),
(3, 'Nhân Viên Công Nhật'),
(4, 'Nhân Viên Quản Trị');

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `sp_deleteEmployee`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_deleteEmployee`(EmployeeID varchar(50))
DELETE
  FROM EMPLOYEE
  WHERE EMPLOYEE.EMPLOYEEID=EMPLOYEEID$$

DROP PROCEDURE IF EXISTS `sp_selectEmployeeByID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_selectEmployeeByID`(EmployeeID varchar (50))
SELECT *
  FROM Employee emp
  WHERE emp.EmployeeID=EmployeeID$$

DROP PROCEDURE IF EXISTS `sp_SelectemployeesAll`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_SelectemployeesAll`()
SELECT
	EmployeeID,
  EmployeeName,
	Email,
	Salary,
	EmployeeStyleID
FROM
	employee$$

DROP PROCEDURE IF EXISTS `sp_Selectemployeestyle`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_Selectemployeestyle`(EmployeeStyleID int)
SELECT
	hrm.EmployeeStyleID,
	hrm.EmployeeStyleName
FROM
	employeestyle
WHERE
	hrm.EmployeeStyleID = EmployeeStyleID$$

DROP PROCEDURE IF EXISTS `sp_SelectemployeestylesAll`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_SelectemployeestylesAll`()
SELECT
	EmployeeStyleID,
        EmployeeStyleName
FROM
	employeestyle$$

DROP PROCEDURE IF EXISTS `sp_UpdateEmployee`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_UpdateEmployee`(EmployeeID varchar (50),EmployeeName varchar (50),Email varchar(50),Salary float,EmployeeStyleID int)
UPDATE Employee
SET
Employee.EmployeeName=EmployeeName,
Employee.Email=Email,
Employee.Salary=Salary,
Employee.EmployeeStyleID=EmployeeStyleID
WHERE Employee.EmployeeID=EmployeeID$$

DELIMITER ;
