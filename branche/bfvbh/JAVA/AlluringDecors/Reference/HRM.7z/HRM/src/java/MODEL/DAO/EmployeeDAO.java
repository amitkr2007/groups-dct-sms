/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL.DAO;

import MODEL.DTO.*;
import MODEL.UTIL.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Nguyen Hoang Anh
 */
public class EmployeeDAO {

    //Inserting
    public static boolean insertEmployee(EmployeeDTO emp) {
        boolean result = true;
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_InsertEmployee(?, ?, ?, ?, ?)}");
            cs.setString("EmployeeID", emp.getEmployeeID());
            cs.setString("EmployeeName", emp.getEmployeeName());
            cs.setString("Email", emp.getEmail());
            cs.setFloat("Salary", emp.getSalary());
            cs.setInt("EmployeeStyleID", emp.getEmployeeStyleID());
            int n = cs.executeUpdate();
            if (n == 0) {
                result =false;
            }
            
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }        
        return result;

    }
    //Deleting

    public static boolean deleteEmployee(String employeeID) {
        boolean result = false;
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_DeleteEmployee(?)}");
            cs.setString("EmployeeID", employeeID);
            int n = cs.executeUpdate();
            if (n == 1) {
                result = true;
            }
            connect.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    //Updating

    public static boolean updateEmployee(EmployeeDTO emp) {
        boolean result = false;
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_UpdateEmployee(?, ?, ?, ?, ?)}");
            cs.setString("EmployeeName", emp.getEmployeeName());
            cs.setString("Email", emp.getEmail());
            cs.setFloat("Salary", emp.getSalary());
            cs.setInt("EmployeeStyleID", emp.getEmployeeStyleID());
            cs.setString("EmployeeID", emp.getEmployeeID());
            int n = cs.executeUpdate();
            if (n == 1) {
                result = true;
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return result;

    }
    //Retrieving  

    public static ArrayList<EmployeeDTO> selectEmployeeAll() {
        ArrayList<EmployeeDTO> list = new ArrayList<EmployeeDTO>();
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_SelectEmployeesAll()}");
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                EmployeeDTO emp = new EmployeeDTO();
                emp.setEmployeeID(rs.getString("EmployeeID"));
                emp.setEmployeeName(rs.getString("EmployeeName"));
                emp.setEmail(rs.getString("Email"));
                emp.setSalary(rs.getFloat("Salary"));
                emp.setEmployeeStyleID(rs.getInt("EmployeeStyleID"));
                list.add(emp);
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public static EmployeeDTO selectEmployeeByID(String employeeID) {
        EmployeeDTO emp = new EmployeeDTO();
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_selectEmployeeByID(?)}");
            cs.setString("EmployeeID", employeeID);
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                emp.setEmployeeID(rs.getString("EmployeeID"));
                emp.setEmployeeName(rs.getString("EmployeeName"));
                emp.setEmail(rs.getString("Email"));
                emp.setSalary(rs.getFloat("Salary"));
                emp.setEmployeeStyleID(rs.getInt("EmployeeStyleID"));
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return emp;
    }

    public static ArrayList<EmployeeDTO> selectEmployeeByEmployeeStyleID(int employeeStyleID) {
        ArrayList<EmployeeDTO> list = new ArrayList<EmployeeDTO>();
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_SelectEmployeesByEmployeeStyleID(?)}");
            cs.setInt("EmployeeStyleID", employeeStyleID);
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                EmployeeDTO emp = new EmployeeDTO();
                emp.setEmployeeID(rs.getString("EmployeeID"));
                emp.setEmployeeName(rs.getString("EmployeeName"));
                emp.setEmail(rs.getString("Email"));
                emp.setSalary(rs.getFloat("Salary"));
                emp.setEmployeeStyleID(rs.getInt("EmployeeStyleID"));
                list.add(emp);
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public static boolean checkEmployeeByID(String employeeID) {
        boolean result = false;
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_selectEmployeeByID(?)}");
            cs.setString("EmployeeID", employeeID);
            ResultSet rs = cs.executeQuery();
            if (rs.next()) {
                result = true;
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
    public static ArrayList<EmployeeDTO> searchEmployeeByName(String employeeName){
        ArrayList<EmployeeDTO> list = new ArrayList<EmployeeDTO>();
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_SearchEmployeeByName(?)}");
            cs.setString("EmployeeName", employeeName);
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                EmployeeDTO emp = new EmployeeDTO();
                emp.setEmployeeID(rs.getString("EmployeeID"));
                emp.setEmployeeName(rs.getString("EmployeeName"));
                emp.setEmail(rs.getString("Email"));
                emp.setSalary(rs.getFloat("Salary"));
                emp.setEmployeeStyleID(rs.getInt("EmployeeStyleID"));
                list.add(emp);
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
}
