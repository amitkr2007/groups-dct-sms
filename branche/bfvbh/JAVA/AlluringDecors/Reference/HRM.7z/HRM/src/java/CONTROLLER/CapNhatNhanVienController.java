/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.BUS.EmployeeBUS;
import MODEL.BUS.EmployeeStyleBUS;
import MODEL.DTO.EmployeeDTO;
import MODEL.DTO.EmployeeStyleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author NHAnh
 */
public class CapNhatNhanVienController extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String new_employee = (String) request.getParameter("new_employee");
            String employeeID = null;
            if (new_employee != null) {
                EmployeeDTO emp = new EmployeeDTO();
                emp.setEmployeeID(request.getParameter("EmployeeID"));
                emp.setEmployeeName(request.getParameter("EmployeeName"));
                emp.setEmail(request.getParameter("Email"));
                emp.setSalary(Float.parseFloat(request.getParameter("Salary")));
                emp.setEmployeeStyleID(Integer.parseInt(request.getParameter("EmployeeStyleID")));
                boolean kq = EmployeeBUS.updateEmployee(emp);
                if (kq == true) {
                    request.setAttribute("Message", "Cập Nhật Thành Công");
                } else {
                    request.setAttribute("Message", "Cập Nhật Thất Bại");
                }
                employeeID = emp.getEmployeeID();

            }
            if (employeeID == null) {
                employeeID = (String) request.getParameter("update");
            }
            if (employeeID != null) {
                EmployeeDTO emp = EmployeeBUS.selectEmployeeByID(employeeID);
                request.setAttribute("EmployeeDTO", emp);
                ArrayList<EmployeeStyleDTO> ds = EmployeeStyleBUS.selectEmployeeStyleAll();
                request.setAttribute("EmployeeStyleDTOs", ds);
            }
            String url = "/VIEW/CapNhatNhanVienView.jsp";
            RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
            rd.forward(request, response);

        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
