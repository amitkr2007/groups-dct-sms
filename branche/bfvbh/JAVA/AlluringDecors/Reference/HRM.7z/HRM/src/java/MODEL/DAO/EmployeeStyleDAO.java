/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL.DAO;

import MODEL.DTO.EmployeeStyleDTO;
import MODEL.UTIL.MySqlDataAccessHelper;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Nguyen Hoang Anh
 */
public class EmployeeStyleDAO {
    //Retrieving

    public static ArrayList<EmployeeStyleDTO> selectEmployeeStyleAll() {
        ArrayList<EmployeeStyleDTO> list = new ArrayList<EmployeeStyleDTO>();
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{CALL sp_SelectemployeestylesAll()}");
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                EmployeeStyleDTO emp = new EmployeeStyleDTO();
                emp.setEmployeeStyleID(rs.getInt("EmployeeStyleID"));
                emp.setEmployeeStyleName(rs.getString("EmployeeStyleName"));
                list.add(emp);
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public static boolean checkEmployeeStyleID(int employeeStyleID) {
        boolean result = false;
        try {
            Connection connect = MySqlDataAccessHelper.getConnection();
            CallableStatement cs = connect.prepareCall("{call sp_SelectEmployeeStyleByID(?)}");
            cs.setInt("EmployeeStyleID", employeeStyleID);
            ResultSet rs = cs.executeQuery();
            if (rs.next()) {
                result = true;
            }
            connect.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return result;
    }
}
