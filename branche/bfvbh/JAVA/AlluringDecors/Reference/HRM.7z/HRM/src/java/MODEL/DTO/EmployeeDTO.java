/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL.DTO;

import java.io.Serializable;

/**
 *
 * @author Nguyen Hoang Anh
 */
public class EmployeeDTO implements Serializable {

    protected String employeeID;
    protected String employeeName;
    protected String email;
    protected float salary;
    protected int employeeStyleID;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public int getEmployeeStyleID() {
        return employeeStyleID;
    }

    public void setEmployeeStyleID(int employeeStyleID) {
        this.employeeStyleID = employeeStyleID;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
}
