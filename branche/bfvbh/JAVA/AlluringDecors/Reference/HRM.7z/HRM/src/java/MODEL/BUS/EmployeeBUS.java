/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL.BUS;

import MODEL.DAO.EmployeeDAO;
import MODEL.DAO.EmployeeStyleDAO;
import MODEL.DTO.EmployeeDTO;
import java.util.ArrayList;

/**
 *
 * @author Nguyen Hoang Anh
 */
public class EmployeeBUS {

    public static boolean insertEmployee(EmployeeDTO emp) {
        boolean result = false;

        if (EmployeeDAO.checkEmployeeByID(emp.getEmployeeID()) &&
                EmployeeStyleDAO.checkEmployeeStyleID(emp.getEmployeeStyleID())) {
            result = false;
        } else {
            result = EmployeeDAO.insertEmployee(emp);

        }
        return result;
    }

    public static boolean deleteEmployee(String employeeID) {
        if (EmployeeDAO.checkEmployeeByID(employeeID)) {
            return EmployeeDAO.deleteEmployee(employeeID);
        } else {
            return false;
        }
    }

    public static boolean updateEmployee(EmployeeDTO emp) {
       if (EmployeeDAO.checkEmployeeByID(emp.getEmployeeID()) &&
                EmployeeStyleDAO.checkEmployeeStyleID(emp.getEmployeeStyleID())) {
            return EmployeeDAO.updateEmployee(emp);
        } else {
            return false;
        }
    }

    public static ArrayList<EmployeeDTO> selectEmployeeByEmployeeStyleID(int employeeStyleID) {
        if (EmployeeStyleDAO.checkEmployeeStyleID(employeeStyleID)) {
            return EmployeeDAO.selectEmployeeByEmployeeStyleID(employeeStyleID);
        } else {
            return new ArrayList<EmployeeDTO>();
        }
    }

    public static ArrayList<EmployeeDTO> selectEmployeeAll() {
        return EmployeeDAO.selectEmployeeAll();
    }

    public static EmployeeDTO selectEmployeeByID(String employeeID) {
        EmployeeDTO emp = null;
        if (EmployeeDAO.checkEmployeeByID(employeeID)) {
            emp = EmployeeDAO.selectEmployeeByID(employeeID);
        }
        return emp;
    }

    public static ArrayList<EmployeeDTO> searchEmployeeByName(String employeeName) {
        return EmployeeDAO.searchEmployeeByName(employeeName);
    }
}
