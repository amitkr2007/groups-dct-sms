/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL.BUS;

import MODEL.DAO.EmployeeStyleDAO;
import MODEL.DTO.EmployeeStyleDTO;
import java.util.ArrayList;

/**
 *
 * @author Nguyen Hoang Anh
 */
public class EmployeeStyleBUS {

    public static ArrayList<EmployeeStyleDTO> selectEmployeeStyleAll() {
        return EmployeeStyleDAO.selectEmployeeStyleAll();
    }
}
