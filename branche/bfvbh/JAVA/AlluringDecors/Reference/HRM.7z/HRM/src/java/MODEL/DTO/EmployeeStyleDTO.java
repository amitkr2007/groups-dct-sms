/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL.DTO;

import java.io.Serializable;

/**
 *
 * @author Nguyen Hoang Anh
 */
public class EmployeeStyleDTO implements Serializable {

    protected int employeeStyleID;
    protected String employeeStyleName;

    public int getEmployeeStyleID() {
        return employeeStyleID;
    }

    public void setEmployeeStyleID(int employeeStyleID) {
        this.employeeStyleID = employeeStyleID;
    }

    public String getEmployeeStyleName() {
        return employeeStyleName;
    }

    public void setEmployeeStyleName(String employeeStyleName) {
        this.employeeStyleName = employeeStyleName;
    }
    @Override
    public String toString(){
        return this.employeeStyleName;
    }
}
