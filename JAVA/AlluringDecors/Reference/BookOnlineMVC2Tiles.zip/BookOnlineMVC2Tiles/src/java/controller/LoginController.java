/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.dao.DanhMucDAO;
import model.dao.KhachHangDAO;
import model.pojo.DanhMuc;
import model.pojo.KhachHang;

/**
 *
 * @author NHAnh - nhanh@fit.hcmus.edu.vn
 */
@WebServlet(name = "LoginController", urlPatterns = {"/LoginController"})
public class LoginController extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("Action");
        if (action != null) {
            if (action.equals("View")) {
                ArrayList<DanhMuc> danhMucs = DanhMucDAO.layDanhSachDanhMuc();
                request.setAttribute("DanhMucs", danhMucs);
                request.getRequestDispatcher("/Login.jsp").forward(request, response);
            }
            if (action.equals("Login")) {
                String tenDangNhap = request.getParameter("tenDangNhap");
                String matKhau = request.getParameter("matKhau");
                KhachHang kh = KhachHangDAO.dangNhap(tenDangNhap, matKhau);
                if (kh != null) {
                    HttpSession session = request.getSession();
                    session.setAttribute("KhachHang", kh);
                    response.sendRedirect("HomeController?Action=View");
                    return;
                } else {
                    String url = "LoginController?Action=View";
                    request.setAttribute("Error", "Tên đăng nhập hoặc mật khẩu  không đúng");
                    request.getRequestDispatcher(url).forward(request, response);
                }

            } else if (action.equals("Logout")) {
                HttpSession session = request.getSession();
                session.removeAttribute("KhachHang");
                response.sendRedirect("LoginController?Action=View");
                return;
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
