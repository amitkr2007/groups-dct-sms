/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.pojo;

/**
 *
 * @author NHAnh
 */
public class KhachHang {

   private String tenDangNhap;
   private String matKhau;
   private String hoVaTen;
   private String diaChi;
   private String email;
   private double tienNo;

   public KhachHang() {
      this.tenDangNhap = "";
      this.matKhau = "";
      this.hoVaTen = "";
      this.diaChi = "";
      this.email = "";
      this.tienNo = 0;
   }

   public KhachHang(String tenDangNhap, String matKhau, String hoVaTen, String diaChi, String email, double tienNo) {
      this.tenDangNhap = tenDangNhap;
      this.matKhau = matKhau;
      this.hoVaTen = hoVaTen;
      this.diaChi = diaChi;
      this.email = email;
      this.tienNo = tienNo;
   }

   public KhachHang(KhachHang kh) {
      this.tenDangNhap = kh.tenDangNhap;
      this.matKhau = kh.matKhau;
      this.hoVaTen = kh.hoVaTen;
      this.diaChi = kh.diaChi;
      this.email = kh.email;
      this.tienNo = kh.tienNo;
   }

   public String getDiaChi() {
      return diaChi;
   }

   public void setDiaChi(String diaChi) {
      this.diaChi = diaChi;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public String getHoVaTen() {
      return hoVaTen;
   }

   public void setHoVaTen(String hoVaTen) {
      this.hoVaTen = hoVaTen;
   }

   public String getMatKhau() {
      return matKhau;
   }

   public void setMatKhau(String matKhau) {
      this.matKhau = matKhau;
   }

   public String getTenDangNhap() {
      return tenDangNhap;
   }

   public void setTenDangNhap(String tenDangNhap) {
      this.tenDangNhap = tenDangNhap;
   }

   public double getTienNo() {
      return tienNo;
   }

   public void setTienNo(double tienNo) {
      this.tienNo = tienNo;
   }

   @Override
   public String toString() {
      return this.hoVaTen;
   }
}
