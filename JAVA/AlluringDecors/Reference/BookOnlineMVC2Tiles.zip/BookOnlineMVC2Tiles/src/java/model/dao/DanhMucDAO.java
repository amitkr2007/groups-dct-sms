/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import model.dao.util.MySqlDataAccessHelper;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSet;

import model.pojo.DanhMuc;

/**
 *
 * @author NHAnh - nhanh@fit.hcmus.edu.vn
 */

public class DanhMucDAO {

    public static ArrayList<DanhMuc> layDanhSachDanhMuc() {
        ArrayList<DanhMuc> ds = new ArrayList<DanhMuc>();
        String sql = "SELECT * FROM DANHMUC";
        MySqlDataAccessHelper helper = new MySqlDataAccessHelper();
        helper.open();
        ResultSet rs = helper.executeQuery(sql);
        try {
            while (rs.next()) {
                DanhMuc danhMuc = new DanhMuc();
                danhMuc.setMaDanhMuc(rs.getString("MaDanhMuc"));
                danhMuc.setTenDanhMuc(rs.getString("TenDanhMuc"));
                ds.add(danhMuc);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        helper.close();
        return ds;
    }

    
}
