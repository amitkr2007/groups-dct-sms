/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.pojo;

import java.io.Serializable;

/**
 * Thông tin về danh mục sách
 * @author NHAnh
 * @version 1.0
 */
public class DanhMuc implements Serializable {

   /**
    * Thuộc tính: maDanhMuc
    */
   private String maDanhMuc;
   /**
    * Thuộc tính: tenDanhMuc
    */
   private String tenDanhMuc;

   /**
    * Phương thức khởi tạo mặc định
    */
   public DanhMuc() {
      this.maDanhMuc = "";
      this.tenDanhMuc = "";
   }

   /**
    * Phương thức khởi tạo đầy đủ tham số
    * @param maDanhMuc mã danh mục sách
    * @param tenDanhMuc tên danh mục sách
    */
   public DanhMuc(String maDanhMuc, String tenDanhMuc) {
      this.maDanhMuc = maDanhMuc;
      this.tenDanhMuc = tenDanhMuc;

   }

   /**
    * Phương thức khởi tạo sao chép
    * @param dm đối tượng danh mục sách
    */
   public DanhMuc(DanhMuc danhMuc) {
      this.maDanhMuc = danhMuc.maDanhMuc;
      this.tenDanhMuc = danhMuc.tenDanhMuc;
   }

   /**
    * Phương thức cung cấp thông tin mã danh mục sách
    * @return mã danh mục sách
    */
   public String getMaDanhMuc() {
      return maDanhMuc;
   }

   /**
    * Phương thức cập nhật thông tin mã danh mục sách
    * @param maDanhMuc : mã danh mục sách
    */
   public void setMaDanhMuc(String maDanhMuc) {
      this.maDanhMuc = maDanhMuc;
   }

   /**
    * Phương thức cung cấp thông tin tên danh mục sách
    * @return tên danh mục sách
    */
   public String getTenDanhMuc() {
      return tenDanhMuc;
   }

   /**
    * Phương thức cập nhật thông tin tên danh mục sách
    * @param tenDanhMuc tên danh mục sách
    */
   public void setTenDanhMuc(String tenDanhMuc) {
      this.tenDanhMuc = tenDanhMuc;
   }

   /**
    * Phương thức cung cấp chuỗi giá trị
    * @return tên danh mục sách
    */
   @Override
   public String toString() {
      return this.tenDanhMuc;
   }
}
