/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.pojo;

import java.io.Serializable;

/**
 *
 * @author NHAnh
 */
public class Sach implements Serializable {

    private String maSach;
    private String tenSach;
    private String tacGia;
    private double giaBan;
    private int soLuong;
    private String hinhAnh;
    private String maDanhMuc;

    public Sach() {
        this.maSach = "";
        this.tenSach = "";
        this.tacGia = "";
        this.giaBan = 0;
        this.soLuong = 0;
        this.maDanhMuc = "";
        this.hinhAnh = "";
    }

    public Sach(String maSach, String tenSach, String tacGia, double giaBan, int soLuong, String maDanhMuc, String hinhAnh) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.tacGia = tacGia;
        this.giaBan = giaBan;
        this.soLuong = soLuong;
        this.hinhAnh = hinhAnh;
        this.maDanhMuc = maDanhMuc;
    }

    public Sach(Sach sach) {
        this.maSach = sach.maSach;
        this.tenSach = sach.tenSach;
        this.tacGia = sach.tacGia;
        this.giaBan = sach.giaBan;
        this.soLuong = sach.soLuong;
        this.hinhAnh = sach.hinhAnh;
        this.maDanhMuc = sach.maDanhMuc;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public String getMaDanhMuc() {
        return maDanhMuc;
    }

    public void setMaDanhMuc(String maDanhMuc) {
        this.maDanhMuc = maDanhMuc;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public String getHinhAnh() {
        return hinhAnh;
    }

    public void setHinhAnh(String hinhAnh) {
        this.hinhAnh = hinhAnh;
    }

    @Override
    public String toString() {
        return this.tenSach;
    }
}
