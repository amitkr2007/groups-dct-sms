/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import model.dao.util.MySqlDataAccessHelper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.pojo.Sach;

/**
 *
 * @author NHAnh - nhanh@fit.hcmus.edu.vn
 */
public class SachDAO {

    public static ArrayList<Sach> layDanhSachTheoDanhMuc(String maDanhMuc) {
        ArrayList<Sach> ds = new ArrayList<Sach>();
        String sql = String.format("SELECT * FROM SACH"
                + " WHERE MADANHMUC='%s'",
                maDanhMuc);
        try {
            MySqlDataAccessHelper helper = new MySqlDataAccessHelper();
            helper.open();
            ResultSet rs = helper.executeQuery(sql);
            ds = layDanhSachSach(rs);
            helper.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return ds;
    }

    public static ArrayList<Sach> timKiemSach(String maDanhMuc, String tenSach) {
        ArrayList<Sach> ds = new ArrayList<Sach>();
        String sql = String.format("SELECT * FROM SACH"
                + " WHERE TENSACH LIKE '%s'",
                "%" + tenSach + "%");
        if (maDanhMuc.equals("All") == false) {
            sql = sql + String.format(" AND MADANHMUC = '%s'", maDanhMuc);
        }
        try {
            MySqlDataAccessHelper helper = new MySqlDataAccessHelper();
            helper.open();
            ResultSet rs = helper.executeQuery(sql);
            ds = layDanhSachSach(rs);
            helper.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return ds;
    }

    private static ArrayList<Sach> layDanhSachSach(ResultSet rs) throws SQLException {
        ArrayList<Sach> ds = new ArrayList<Sach>();
        while (rs.next()) {
            Sach sach = new Sach();
            sach.setMaSach(rs.getString("MaSach"));
            sach.setTenSach(rs.getString("TenSach"));
            sach.setTacGia(rs.getString("TacGia"));
            sach.setSoLuong(rs.getInt("SoLuong"));
            sach.setGiaBan(rs.getDouble("GiaBan"));
            sach.setHinhAnh(rs.getString("HinhAnh"));
            sach.setMaDanhMuc(rs.getString("MaDanhMuc"));
            ds.add(sach);
        }
        return ds;
    }

    public static Sach layThongTinSach(String maSach) {
        Sach sach = null;
        String sql = String.format("SELECT * FROM SACH WHERE MASACH='%s'", maSach);
        try {
            MySqlDataAccessHelper helper = new MySqlDataAccessHelper();
            helper.open();
            ResultSet rs = helper.executeQuery(sql);
            if (rs.next()) {
                sach = new Sach();
                sach.setMaSach(rs.getString("MaSach"));
                sach.setTenSach(rs.getString("TenSach"));
                sach.setTacGia(rs.getString("TacGia"));
                sach.setSoLuong(rs.getInt("SoLuong"));
                sach.setGiaBan(rs.getDouble("GiaBan"));
                sach.setHinhAnh(rs.getString("HinhAnh"));
                sach.setMaDanhMuc(rs.getString("MaDanhMuc"));
            }
            helper.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return sach;
    }
}
