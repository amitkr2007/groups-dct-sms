/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import model.dao.util.MySqlDataAccessHelper;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.pojo.KhachHang;


/**
 *
 * @author NHAnh - nhanh@fit.hcmus.edu.vn
 */
public class KhachHangDAO {

    public static KhachHang dangNhap(String tenDangNhap, String matKhau) {
        KhachHang kh = null;
        try {
            String sql = String.format("SELECT * FROM KHACHHANG WHERE TENDANGNHAP=BINARY('%s')"
                    + " AND MATKHAU=BINARY('%s')", tenDangNhap, matKhau);
            MySqlDataAccessHelper helper = new MySqlDataAccessHelper();
            helper.open();
            ResultSet rs = helper.executeQuery(sql);
            if (rs.next()) {
                kh = new KhachHang();
                kh.setTenDangNhap(rs.getString("TenDangNhap"));
                kh.setMatKhau(rs.getString("MatKhau"));
                kh.setHoVaTen(rs.getString("HoVaTen"));
                kh.setDiaChi(rs.getString("DiaChi"));
                kh.setEmail(rs.getString("Email"));
                kh.setTienNo(rs.getDouble("TienNo"));
            }
            helper.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return kh;
    }
}
