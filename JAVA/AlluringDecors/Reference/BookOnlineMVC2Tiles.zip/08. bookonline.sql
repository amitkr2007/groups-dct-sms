-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 26, 2011 at 01:46 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bookonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `chitietdondathang`
--

CREATE TABLE IF NOT EXISTS `chitietdondathang` (
  `MaDonDatHang` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SoThuTu` int(10) unsigned NOT NULL,
  `MaSach` varchar(45) NOT NULL,
  `SoLuong` int(10) unsigned NOT NULL,
  `DonGia` double NOT NULL,
  PRIMARY KEY (`MaDonDatHang`,`SoThuTu`) USING BTREE,
  KEY `FK_chitietdondathang_sach` (`MaSach`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `chitietdondathang`
--

INSERT INTO `chitietdondathang` (`MaDonDatHang`, `SoThuTu`, `MaSach`, `SoLuong`, `DonGia`) VALUES
(3, 1, 'S001', 1, 100000.55),
(4, 1, 'S001', 1, 100000.55),
(4, 2, 'S002', 1, 200000),
(4, 3, 'S006', 1, 110000),
(5, 1, 'S001', 1, 100000.55),
(5, 2, 'S002', 1, 200000),
(6, 1, 'S002', 100000, 200000),
(7, 1, 'S001', 1, 100000.55),
(10, 1, 'S002', 1, 200000),
(11, 1, 'S002', 1, 200000),
(12, 1, 'S001', 1, 100000.55);

-- --------------------------------------------------------

--
-- Table structure for table `danhmuc`
--

CREATE TABLE IF NOT EXISTS `danhmuc` (
  `MaDanhMuc` varchar(45) NOT NULL,
  `TenDanhMuc` varchar(45) NOT NULL,
  PRIMARY KEY (`MaDanhMuc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `danhmuc`
--

INSERT INTO `danhmuc` (`MaDanhMuc`, `TenDanhMuc`) VALUES
('DM001', 'Java'),
('DM002', 'C#'),
('DM010', 'Java2'),
('DM012', 'Java2'),
('DM013', 'Java2');

-- --------------------------------------------------------

--
-- Table structure for table `dondathang`
--

CREATE TABLE IF NOT EXISTS `dondathang` (
  `MaDonDatHang` int(10) unsigned NOT NULL,
  `NgayDatHang` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TenDangNhap` varchar(45) NOT NULL,
  `MaTinhTrang` int(10) unsigned NOT NULL,
  PRIMARY KEY (`MaDonDatHang`),
  KEY `FK_dondathang_khachhang` (`TenDangNhap`),
  KEY `FK_dondathang_tinhtrang` (`MaTinhTrang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dondathang`
--

INSERT INTO `dondathang` (`MaDonDatHang`, `NgayDatHang`, `TenDangNhap`, `MaTinhTrang`) VALUES
(0, '2010-10-25 05:38:49', 'nhanh', 1),
(1, '2010-10-25 04:49:05', 'nhanh', 1),
(2, '2010-10-25 05:45:36', 'nhanh', 1),
(3, '2010-10-25 05:46:45', 'nhanh', 1),
(4, '2010-10-25 05:47:13', 'nhanh', 1),
(5, '2010-10-29 00:52:54', 'nhanh', 1),
(6, '2011-01-02 11:43:36', 'nhanh', 1),
(7, '2011-01-02 11:53:47', 'nhanh', 1),
(8, '2011-01-02 11:55:34', 'nhanh', 1),
(9, '2011-01-02 11:55:41', 'nhanh', 1),
(10, '2011-01-02 11:55:50', 'nhanh', 1),
(11, '2011-01-02 11:56:58', 'nhanh', 1),
(12, '2011-01-13 09:28:18', 'nhanh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE IF NOT EXISTS `khachhang` (
  `TenDangNhap` varchar(45) CHARACTER SET latin1 NOT NULL,
  `MatKhau` varchar(45) CHARACTER SET latin1 NOT NULL,
  `HoVaTen` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `DiaChi` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(45) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`TenDangNhap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`TenDangNhap`, `MatKhau`, `HoVaTen`, `DiaChi`, `Email`) VALUES
('anh', 'anh', 'anh', 'anh', 'anh'),
('anh2', 'anh', 'nguyễn hoàng anh', 'anh', 'anh'),
('nguyen', 'nguyen', 'nguyá»n hoÃ ng anh', '227 Nguyá»n VÄn cá»«', 'hoanganhis@gmail.com'),
('nhanh', 'nhanh', 'Nguyễn Hoàng Anh', '227 Nguyễn Văn Cừ', 'hoanganhis@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `sach`
--

CREATE TABLE IF NOT EXISTS `sach` (
  `MaSach` varchar(45) CHARACTER SET latin1 NOT NULL,
  `TenSach` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `TacGia` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `GiaBan` double NOT NULL,
  `SoLuong` int(10) unsigned NOT NULL,
  `MaDanhMuc` varchar(45) CHARACTER SET latin1 NOT NULL,
  `HinhAnh` varchar(45) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`MaSach`),
  KEY `FK_sach_MaDanhMuc` (`MaDanhMuc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sach`
--

INSERT INTO `sach` (`MaSach`, `TenSach`, `TacGia`, `GiaBan`, `SoLuong`, `MaDanhMuc`, `HinhAnh`) VALUES
('S001', 'Java 1', 'Nguyễn Văn Tùng', 100000.55, 200, 'DM001', 'images/1.jpg'),
('S002', 'Java 2', 'Nguyễn Văn Sơn', 200000, 300, 'DM001', 'images/2.jpg'),
('S003', 'Java 3', 'Nguyễn Thị Bưởi', 150000, 150, 'DM001', 'images/3.jpg'),
('S004', 'Java 4', 'Nguyễn Thị Lan', 300000, 500, 'DM001', 'images/4.jpg'),
('S005', 'Java 5', 'Nguyễn Thành Trung', 220000, 310, 'DM001', 'images/5.jpg'),
('S006', 'C# 1', 'Nguyễn Văn Lý', 110000, 140, 'DM002', 'images/6.jpg'),
('S007', 'C# 2', 'Trần Tùng Sơn', 320000, 343, 'DM002', 'images/7.jpg'),
('S008', 'C# 3', 'Lý Diệu Hà', 321000, 124, 'DM002', 'images/8.jpg'),
('S009', 'C# 4', 'Trần Trung Dũng', 210000, 125, 'DM002', 'images/9.jpg'),
('S010', 'C# 5', 'Nguyễn Hùng Hậu', 143000, 342, 'DM002', 'images/10.jpg'),
('S020', 'Hibernate 3', 'Nguy?n Hoàng Anh', 200000, 1000, 'DM010', 'images/hibernate3.jpg'),
('S021', 'Hibernate 3', 'Nguy?n Hoàng Anh', 200000, 1000, 'DM010', 'images/hibernate3.jpg'),
('S022', 'Hibernate 3', 'Nguy?n Hoàng Anh', 200000, 1000, 'DM010', 'images/hibernate3.jpg'),
('S023', 'Hibernate 3', 'Nguyễn Hoàng Anh', 200000, 1000, 'DM010', 'images/hibernate3.jpg'),
('S024', 'Hibernate 3', 'Nguyễn Hoàng Anh', 200000, 1000, 'DM010', 'images/hibernate3.jpg'),
('S025', 'Hibernate 3', 'Nguyễn Hoàng Anh', 200000, 1000, 'DM010', 'images/hibernate3.jpg'),
('S026', 'Hibernate 3', 'Nguyễn Hoàng Anh', 200000, 1000, 'DM013', 'images/hibernate3.jpg'),
('S027', 'Hibernate 3', 'Nguyễn Hoàng Anh', 200000, 1000, 'DM013', 'images/hibernate3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `thamso`
--

CREATE TABLE IF NOT EXISTS `thamso` (
  `ID` int(11) NOT NULL,
  `SoSanPhamTrenTrang` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thamso`
--

INSERT INTO `thamso` (`ID`, `SoSanPhamTrenTrang`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tinhtrangdondathang`
--

CREATE TABLE IF NOT EXISTS `tinhtrangdondathang` (
  `MaTinhTrang` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TenTinhTrang` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`MaTinhTrang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tinhtrangdondathang`
--

INSERT INTO `tinhtrangdondathang` (`MaTinhTrang`, `TenTinhTrang`) VALUES
(1, 'Mới đặt hàng'),
(2, 'Hủy bởi quản trị'),
(3, 'Chấp nhận bởi quản trị'),
(4, 'Khách hàng đã thanh toán'),
(5, 'Hàng đã được chuyển');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chitietdondathang`
--
ALTER TABLE `chitietdondathang`
  ADD CONSTRAINT `FK_chitietdondathang_dondathang` FOREIGN KEY (`MaDonDatHang`) REFERENCES `dondathang` (`MaDonDatHang`),
  ADD CONSTRAINT `FK_chitietdondathang_sach` FOREIGN KEY (`MaSach`) REFERENCES `sach` (`MaSach`);

--
-- Constraints for table `dondathang`
--
ALTER TABLE `dondathang`
  ADD CONSTRAINT `FK_dondathang_khachhang` FOREIGN KEY (`TenDangNhap`) REFERENCES `khachhang` (`TenDangNhap`),
  ADD CONSTRAINT `FK_dondathang_tinhtrang` FOREIGN KEY (`MaTinhTrang`) REFERENCES `tinhtrangdondathang` (`MaTinhTrang`);

--
-- Constraints for table `sach`
--
ALTER TABLE `sach`
  ADD CONSTRAINT `FK_sach_MaDanhMuc` FOREIGN KEY (`MaDanhMuc`) REFERENCES `danhmuc` (`MaDanhMuc`);
